# @cogenta/fixture-test

## 1.2.3

### Minor Changes

- Some change touching contract A (schema@2.0) — breaking, see ADR-0022.

## 1.2.2

### Patch Changes

- A small fix.
